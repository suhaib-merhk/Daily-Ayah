# ئایەتی ڕۆژ — Daily Ayah v2.0 (Android)

## Features
- One new ayah every day from all 6,236 — random order, never repeats
- Tafsiri Asan (Dr. Burhan Muhammad-Amin) in Kurdish Sorani, fully offline
- Daily notification with Arabic + Kurdish on the lock screen, at your chosen time (on/off switch)
- 10 nature backgrounds (change daily or pick one), or use your own photo from the gallery
- Listen to the ayah — 5 reciters (Alafasy, Abdul Basit, Husary, Sudais, Maher) — needs internet
- Favorites ❤ and a favorites list
- History of all previous days
- Copy text, share as a picture
- Text size setting
- Home-screen widget with today's ayah
- Progress bar: ayah X of 6,236

## Update (if you already built v1 on GitHub)
Delete the old `DailyAyah.zip` in your repository, upload the new `DailyAyah.zip`
(same name), commit. The build runs again; install the new APK over the old one.
Your favorites and ayah order are kept.

## Add the widget
Long-press the home screen → Widgets → ئایەتی ڕۆژ → drag it onto the screen.

## Credits
Text: Tanzil.net · Translation: Tafsiri Asan · Audio: EveryAyah.com · Font: Amiri Quran (OFL)
