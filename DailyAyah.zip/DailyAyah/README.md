# Daily Ayah — ئایەتی ڕۆژ v3.1 (Android)
Developed by Suhaib Najib — Electrical Engineer

## Features
- One new ayah every day from all 6,236 — random order, never repeats
- Tafsiri Asan (Dr. Burhan Muhammad-Amin) in Kurdish Sorani, fully offline
- Daily notification with Arabic + Kurdish on the lock screen, at your chosen time (on/off switch)
- 10 nature backgrounds (change daily or pick one), or use your own photo from the gallery
- Listen to the ayah — 5 reciters (Alafasy, Abdul Basit, Husary, Sudais, Maher) — needs internet
- Favorites ❤ and a favorites list
- History of all previous days
- Copy text, share as a picture
- Text size setting
- Home-screen widget with today's ayah
- Progress bar: ayah X of 6,236
- NEW v3: Daily streak 🔥 with "خوێندمەوە ✓" button, best streak, monthly and yearly challenges,
  month calendar, medals at 7 / 30 / 100 / 265 / 365 days, 9 PM reminder so the streak doesn't break
- NEW v3: Friday reminder to read Surah al-Kahf, with the full surah (Arabic + Kurdish) inside the app
- NEW v3: About page (developer: Suhaib Najib)
- NEW v3.1: Three languages — English (default), Arabic, Kurdish. The language button (EN) in the top bar
  changes the whole app AND the meaning under the ayah:
  English = Saheeh International, Arabic = Tafsir al-Jalalayn, Kurdish = Tafsiri Asan
- NEW v3.1: Keep your streak after updating — on first launch (or Settings → Streak) pick the day you started,
  and every day from then until yesterday is counted
- NEW v3: Fixed signing key — future updates install over the old app and keep your data

## Update to v3 — IMPORTANT, one time only
v1/v2 were signed with a random key, so v3 cannot install over them.
Uninstall the old app once, then install v3. From v3 on, every update installs over the old one.

## Update (normal)
Delete the old `DailyAyah.zip` in your repository, upload the new `DailyAyah.zip`
(same name), commit. The build runs again; install the new APK over the old one.
Your favorites and ayah order are kept.

## Add the widget
Long-press the home screen → Widgets → ئایەتی ڕۆژ → drag it onto the screen.

## Credits
Text: Tanzil.net · Translation: Tafsiri Asan · Audio: EveryAyah.com · Font: Amiri Quran (OFL)
