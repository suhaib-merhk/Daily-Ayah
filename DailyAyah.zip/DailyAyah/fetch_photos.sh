#!/usr/bin/env bash
# Runs on GitHub before building: downloads the Unsplash photos listed in photos.txt
# into the app (portrait 1080x1920). A photo that fails to download is simply skipped.
cd "$(dirname "$0")"
OUT=app/src/main/assets/photos
mkdir -p "$OUT"
: > "$OUT/credits.txt"
n=0
grep -v '^#' photos.txt | while IFS='|' read -r url who; do
  url=$(echo "$url" | xargs); who=$(echo "$who" | xargs)
  [ -z "$url" ] && continue
  n=$((n+1)); name=$(printf "photo%02d.jpg" "$n")
  if curl -fsSL --retry 3 --max-time 60 -o "$OUT/$name" \
       "$url?w=1080&h=1920&fit=crop&crop=entropy&q=72&fm=jpg"; then
    echo "$name|$who" >> "$OUT/credits.txt"
    echo "OK   $name  ($who)"
  else
    rm -f "$OUT/$name"; echo "SKIP $url"
  fi
done
echo "Photos in app: $(ls "$OUT"/*.jpg 2>/dev/null | wc -l)"
