package com.suhaib.dailyayah

import android.app.Activity
import android.app.TimePickerDialog
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class SettingsActivity : Activity() {

    private val pickPhoto = 7
    private lateinit var tvTime: TextView
    private lateinit var thumbs: LinearLayout
    private lateinit var rgBg: RadioGroup

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)
        findViewById<ImageButton>(R.id.btnBack).setOnClickListener { finish() }

        // ---- Notification ----
        val sw = findViewById<Switch>(R.id.swNotify)
        sw.isChecked = Settings.notifyEnabled(this)
        sw.setOnCheckedChangeListener { _, on ->
            Settings.setNotifyEnabled(this, on)
            Scheduler.scheduleDaily(this)
        }
        tvTime = findViewById(R.id.tvTime)
        showTime()
        tvTime.setOnClickListener {
            TimePickerDialog(this, { _, h, m ->
                Settings.setTime(this, h, m)
                Scheduler.scheduleDaily(this)
                showTime()
            }, Settings.hour(this), Settings.minute(this), true).show()
        }
        findViewById<Button>(R.id.btnTest).setOnClickListener {
            if (Notifier.canNotify(this)) { Notifier.show(this); toast("ئاگادارکردنەوە نێردرا") }
            else openNotificationSettings()
        }
        findViewById<Button>(R.id.btnNotifSettings).setOnClickListener { openNotificationSettings() }
        findViewById<Button>(R.id.btnBattery).setOnClickListener {
            try {
                startActivity(Intent(android.provider.Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            } catch (e: Exception) {
                startActivity(Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.parse("package:$packageName")))
            }
        }

        // ---- Text size ----
        val sb = findViewById<SeekBar>(R.id.sbSize)
        val ar = findViewById<TextView>(R.id.tvSizeArabic)
        val ku = findViewById<TextView>(R.id.tvSizeKurdish)
        fun preview() {
            val s = Settings.textScale(this)
            ar.textSize = 26f * s
            ku.textSize = 17f * s
        }
        sb.progress = Settings.sizeStep(this)
        preview()
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                Settings.setSizeStep(this@SettingsActivity, p); preview()
            }
            override fun onStartTrackingTouch(s: SeekBar) {}
            override fun onStopTrackingTouch(s: SeekBar) {}
        })

        // ---- Background ----
        rgBg = findViewById(R.id.rgBg)
        thumbs = findViewById(R.id.thumbs)
        buildThumbs()
        checkBgRadio()
        rgBg.setOnCheckedChangeListener { _, id ->
            when (id) {
                R.id.rbDaily -> Settings.setBgMode(this, "daily")
                R.id.rbFixed -> Settings.setBgMode(this, "fixed")
                R.id.rbCustom -> {
                    if (getFileStreamPath("custom_bg.jpg").exists()) Settings.setBgMode(this, "custom")
                    else pickFromGallery()
                }
            }
            highlightThumbs()
        }
        findViewById<Button>(R.id.btnPickPhoto).setOnClickListener { pickFromGallery() }

        // ---- Reciter ----
        val rgReciter = findViewById<RadioGroup>(R.id.rgReciter)
        Reciters.names.forEachIndexed { i, name ->
            rgReciter.addView(RadioButton(this).apply {
                id = 1000 + i
                text = name
                setTextColor(Color.WHITE)
                textSize = 16f
            })
        }
        rgReciter.check(1000 + Settings.reciter(this))
        rgReciter.setOnCheckedChangeListener { _, id -> Settings.setReciter(this, id - 1000) }
    }

    private fun showTime() {
        tvTime.text = "🕐  کاتی ئاگادارکردنەوە:  %02d:%02d  (دەستکاری)".format(Settings.hour(this), Settings.minute(this))
    }

    private fun checkBgRadio() {
        rgBg.check(when (Settings.bgMode(this)) {
            "fixed" -> R.id.rbFixed
            "custom" -> R.id.rbCustom
            else -> R.id.rbDaily
        })
    }

    private fun buildThumbs() {
        val d = resources.displayMetrics.density
        Backgrounds.nature.indices.forEach { i ->
            val iv = ImageView(this).apply {
                layoutParams = LinearLayout.LayoutParams((64 * d).toInt(), (112 * d).toInt()).apply {
                    marginEnd = (8 * d).toInt()
                }
                scaleType = ImageView.ScaleType.CENTER_CROP
                setPadding((3 * d).toInt(), (3 * d).toInt(), (3 * d).toInt(), (3 * d).toInt())
                setImageBitmap(Backgrounds.thumbnail(this@SettingsActivity, i))
                setOnClickListener {
                    Settings.setFixedBg(this@SettingsActivity, i)
                    Settings.setBgMode(this@SettingsActivity, "fixed")
                    checkBgRadio()
                    highlightThumbs()
                }
            }
            thumbs.addView(iv)
        }
        highlightThumbs()
    }

    private fun highlightThumbs() {
        val fixed = Settings.bgMode(this) == "fixed"
        for (i in 0 until thumbs.childCount) {
            thumbs.getChildAt(i).setBackgroundColor(
                if (fixed && i == Settings.fixedBg(this)) Color.parseColor("#66BB6A") else Color.TRANSPARENT
            )
        }
    }

    private fun pickFromGallery() {
        startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).setType("image/*"), pickPhoto)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != pickPhoto) return
        val uri = data?.data
        if (resultCode != RESULT_OK || uri == null) { checkBgRadio(); return }
        toast("چاوەڕێ بکە…")
        Thread {
            val ok = Backgrounds.saveCustom(this, uri)
            runOnUiThread {
                if (ok) { Settings.setBgMode(this, "custom"); toast("وێنەکە دانرا") }
                else toast("نەتوانرا وێنەکە بکرێتەوە")
                checkBgRadio(); highlightThumbs()
            }
        }.start()
    }

    private fun openNotificationSettings() {
        startActivity(
            Intent(android.provider.Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                .putExtra(android.provider.Settings.EXTRA_APP_PACKAGE, packageName)
        )
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
}
