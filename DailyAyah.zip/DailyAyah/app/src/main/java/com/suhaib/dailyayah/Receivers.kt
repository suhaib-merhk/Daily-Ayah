package com.suhaib.dailyayah

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val result = goAsync()
        Thread {
            try {
                when (intent.action) {
                    Scheduler.ACTION_MIDNIGHT -> {
                        AyahWidget.updateAll(context)
                        Scheduler.scheduleMidnight(context)
                    }
                    Scheduler.ACTION_KAHF -> {
                        Notifier.showKahf(context)
                        Scheduler.scheduleKahf(context)
                    }
                    Scheduler.ACTION_STREAK -> {
                        if (!Streak.isReadToday(context)) Notifier.showStreakReminder(context)
                        Scheduler.scheduleStreak(context)
                    }
                    else -> {
                        Notifier.show(context)
                        AyahWidget.updateAll(context)
                        Scheduler.scheduleDaily(context)
                    }
                }
            } finally {
                result.finish()
            }
        }.start()
    }
}

/** Alarms are cleared on reboot / app update / clock change, so book them again. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        Scheduler.scheduleAll(context)
        AyahWidget.updateAll(context)
    }
}
