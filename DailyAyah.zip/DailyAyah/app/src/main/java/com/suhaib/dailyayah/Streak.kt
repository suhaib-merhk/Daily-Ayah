package com.suhaib.dailyayah

import android.content.Context
import java.time.LocalDate
import java.time.YearMonth

/**
 * Reading streak. A day counts when the user taps "خوێندمەوە" on today's ayah.
 * Days are stored as epoch-day numbers.
 */
object Streak {
    val milestones = intArrayOf(7, 30, 100, 265, 365)

    private fun p(ctx: Context) = AyahRepository.prefs(ctx)

    fun readDays(ctx: Context): Set<Long> =
        (p(ctx).getString("read_days", "") ?: "").split(',')
            .filter { it.isNotBlank() }.map { it.toLong() }.toSet()

    fun isReadToday(ctx: Context) = LocalDate.now().toEpochDay() in readDays(ctx)

    /** Marks today as read. Returns the new current streak. */
    fun markToday(ctx: Context): Int {
        val days = readDays(ctx).toMutableSet()
        days.add(LocalDate.now().toEpochDay())
        p(ctx).edit().putString("read_days", days.sorted().joinToString(",")).apply()
        val cur = current(ctx)
        if (cur > best(ctx)) p(ctx).edit().putInt("best_streak", cur).apply()
        return cur
    }

    /**
     * Counts every day from [from] up to yesterday as read — used once after updating
     * from an older version, so the streak continues. Returns how many days were added.
     */
    fun backfill(ctx: Context, from: LocalDate): Int {
        val days = readDays(ctx).toMutableSet()
        val before = days.size
        var d = from.toEpochDay()
        val end = LocalDate.now().toEpochDay() - 1
        while (d <= end) { days.add(d); d++ }
        p(ctx).edit()
            .putString("read_days", days.sorted().joinToString(","))
            .putBoolean("backfill_asked", true)
            .apply()
        val cur = current(ctx)
        if (cur > best(ctx)) p(ctx).edit().putInt("best_streak", cur).apply()
        return days.size - before
    }

    fun backfillAsked(ctx: Context) = p(ctx).getBoolean("backfill_asked", false)
    fun setBackfillAsked(ctx: Context) = p(ctx).edit().putBoolean("backfill_asked", true).apply()

    /** Consecutive days up to today (or up to yesterday if today isn't read yet). */
    fun current(ctx: Context): Int {
        val days = readDays(ctx)
        var d = LocalDate.now().toEpochDay()
        if (d !in days) d -= 1
        var n = 0
        while (d in days) { n++; d-- }
        return n
    }

    fun best(ctx: Context): Int = maxOf(p(ctx).getInt("best_streak", 0), current(ctx))

    fun total(ctx: Context) = readDays(ctx).size

    fun countInMonth(ctx: Context, ym: YearMonth = YearMonth.now()): Int {
        val a = ym.atDay(1).toEpochDay(); val b = ym.atEndOfMonth().toEpochDay()
        return readDays(ctx).count { it in a..b }
    }

    fun countInYear(ctx: Context, year: Int = LocalDate.now().year): Int {
        val a = LocalDate.of(year, 1, 1).toEpochDay(); val b = LocalDate.of(year, 12, 31).toEpochDay()
        return readDays(ctx).count { it in a..b }
    }

    // ---------- Surah al-Kahf on Fridays ----------

    fun kahfFridays(ctx: Context) = p(ctx).getInt("kahf_count", 0)

    fun isKahfDoneThisWeek(ctx: Context) =
        p(ctx).getLong("kahf_last", -1) == lastFriday().toEpochDay()

    fun markKahf(ctx: Context): Boolean {
        if (isKahfDoneThisWeek(ctx)) return false
        p(ctx).edit()
            .putLong("kahf_last", lastFriday().toEpochDay())
            .putInt("kahf_count", kahfFridays(ctx) + 1)
            .apply()
        return true
    }

    /** The most recent Friday (today if today is Friday). */
    private fun lastFriday(): LocalDate {
        var d = LocalDate.now()
        while (d.dayOfWeek != java.time.DayOfWeek.FRIDAY) d = d.minusDays(1)
        return d
    }
}
