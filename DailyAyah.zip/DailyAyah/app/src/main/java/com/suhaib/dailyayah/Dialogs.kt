package com.suhaib.dailyayah

import android.app.Activity
import android.app.AlertDialog
import android.app.DatePickerDialog
import android.widget.Toast
import java.time.LocalDate
import java.time.ZoneId

/** Language picker: English / العربية / کوردی. Reopens the screen in the new language. */
fun chooseLanguage(a: Activity) {
    val current = Lang.all.indexOf(Lang.get(a))
    AlertDialog.Builder(a)
        .setTitle("Language · اللغة · زمان")
        .setSingleChoiceItems(Lang.labels, current) { d, which ->
            d.dismiss()
            if (which != current) {
                Lang.set(a, Lang.all[which])
                Notifier.createChannel(a)       // rename channels in the new language
                AyahWidget.updateAll(a)
                a.recreate()
            }
        }
        .show()
}

/** Pick the first day of an earlier streak; all days from then until yesterday count as read. */
fun pickBackfillDate(a: Activity, done: () -> Unit) {
    val start = LocalDate.now().minusDays(1)
    val dlg = DatePickerDialog(a, { _, y, m, d ->
        val added = Streak.backfill(a, LocalDate.of(y, m + 1, d))
        Toast.makeText(a, a.getString(R.string.backfill_done, Lang.num(a, added)), Toast.LENGTH_LONG).show()
        done()
    }, start.year, start.monthValue - 1, start.dayOfMonth)
    dlg.datePicker.maxDate = start.atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli()
    dlg.show()
}
