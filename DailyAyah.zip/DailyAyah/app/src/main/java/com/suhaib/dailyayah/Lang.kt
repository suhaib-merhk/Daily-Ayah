package com.suhaib.dailyayah

import android.app.Activity
import android.content.Context
import android.content.res.Configuration
import android.os.Bundle
import android.view.View
import java.util.Locale

/** App language: English (default), Arabic or Kurdish Sorani. */
object Lang {
    const val EN = "en"
    const val AR = "ar"
    const val KU = "ckb"
    val all = arrayOf(EN, AR, KU)
    val labels = arrayOf("English", "العربية", "کوردی")
    /** Short label shown on the language button */
    fun short(code: String) = when (code) { AR -> "ع"; KU -> "کو"; else -> "EN" }

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("daily_ayah", Context.MODE_PRIVATE)

    fun get(ctx: Context): String = prefs(ctx).getString("lang", EN) ?: EN
    fun set(ctx: Context, code: String) = prefs(ctx).edit().putString("lang", code).commit()
    fun isRtl(ctx: Context) = get(ctx) != EN

    /** A context whose resources use the app language (for activities, notifications, widget). */
    fun wrap(base: Context): Context {
        val loc = Locale(get(base))
        val cfg = Configuration(base.resources.configuration)
        cfg.setLocale(loc)
        cfg.setLayoutDirection(loc)
        return base.createConfigurationContext(cfg)
    }

    /** Arabic-Indic digits for Arabic/Kurdish, normal digits for English. */
    fun num(ctx: Context, n: Int): String = if (get(ctx) == EN) n.toString() else arabicDigits(n)
}

/** All screens extend this so they follow the chosen language and direction. */
open class BaseActivity : Activity() {
    private var langAtCreate = ""

    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(Lang.wrap(newBase))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        langAtCreate = Lang.get(this)
    }

    override fun setContentView(layoutResID: Int) {
        super.setContentView(layoutResID)
        window.decorView.layoutDirection =
            if (Lang.isRtl(this)) View.LAYOUT_DIRECTION_RTL else View.LAYOUT_DIRECTION_LTR
    }

    override fun onResume() {
        super.onResume()
        if (langAtCreate.isNotEmpty() && langAtCreate != Lang.get(this)) recreate()
    }
}
