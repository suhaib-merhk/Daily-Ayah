package com.suhaib.dailyayah

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast

/** Reads a whole surah (used for Surah al-Kahf on Fridays). */
class SurahActivity : BaseActivity() {

    companion object { const val EXTRA_SURAH = "surah" }

    private lateinit var ayat: List<Ayah>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_list)
        val surah = intent.getIntExtra(EXTRA_SURAH, 18)
        ayat = AyahRepository.surah(this, surah)

        findViewById<TextView>(R.id.title).text = ayat.firstOrNull()?.let { if (it.lang == Lang.EN) "Surah ${it.surahEnglish}" else it.surahArabic } ?: ""
        findViewById<ImageButton>(R.id.btnBack).setOnClickListener { finish() }

        val d = resources.displayMetrics.density
        val list = findViewById<ListView>(R.id.list)

        // Header: Bismillah
        list.addHeaderView(TextView(this).apply {
            text = "بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ"
            typeface = resources.getFont(R.font.amiri_quran)
            textSize = 24f
            setTextColor(Color.parseColor("#E9C46A"))
            gravity = Gravity.CENTER
            setPadding(0, (8 * d).toInt(), 0, (12 * d).toInt())
        }, null, false)

        // Footer: "I finished" button (counts toward Friday Kahf total)
        if (surah == 18) {
            val footer = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(0, (12 * d).toInt(), 0, (24 * d).toInt())
            }
            val done = Button(this).apply {
                text = getString(if (Streak.isKahfDoneThisWeek(this@SurahActivity)) R.string.kahf_done_already
                               else R.string.kahf_done_btn)
                setOnClickListener {
                    if (Streak.markKahf(this@SurahActivity)) {
                        text = getString(R.string.kahf_done_already)
                        Toast.makeText(this@SurahActivity,
                            getString(R.string.kahf_toast, Lang.num(this@SurahActivity, Streak.kahfFridays(this@SurahActivity))),
                            Toast.LENGTH_LONG).show()
                    }
                }
            }
            footer.addView(done)
            list.addFooterView(footer, null, false)
        }

        list.adapter = VerseAdapter()
    }

    private inner class VerseAdapter : BaseAdapter() {
        override fun getCount() = ayat.size
        override fun getItem(position: Int): Any = ayat[position]
        override fun getItemId(position: Int) = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val v = convertView ?: layoutInflater.inflate(R.layout.item_verse, parent, false)
            val a = ayat[position]
            v.findViewById<TextView>(R.id.v_arabic).text = "${a.arabic} ﴿${arabicDigits(a.number)}﴾"
            v.findViewById<TextView>(R.id.v_kurdish).text = a.meaning
            return v
        }
    }
}
