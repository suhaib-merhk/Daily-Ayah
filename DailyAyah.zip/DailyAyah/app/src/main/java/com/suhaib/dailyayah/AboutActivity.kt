package com.suhaib.dailyayah

import android.app.Activity
import android.os.Bundle
import android.widget.ImageButton
import android.widget.TextView

class AboutActivity : BaseActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_about)
        findViewById<ImageButton>(R.id.btnBack).setOnClickListener { finish() }
        val v = packageManager.getPackageInfo(packageName, 0).versionName
        findViewById<TextView>(R.id.abVersion).text = getString(R.string.version, v)
        val names = Backgrounds.credits(this)
        findViewById<TextView>(R.id.abPhotoCredits).text =
            if (names.isEmpty()) "" else getString(R.string.sec_photo_credits) + "\n" + names.joinToString(" · ")
    }
}
