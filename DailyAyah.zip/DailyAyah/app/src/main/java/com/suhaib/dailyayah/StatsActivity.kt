package com.suhaib.dailyayah

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.widget.GridLayout
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import java.time.LocalDate
import java.time.YearMonth

/** Streak, monthly and yearly challenge, calendar and badges. */
class StatsActivity : BaseActivity() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_stats)
        findViewById<ImageButton>(R.id.btnBack).setOnClickListener { finish() }
    }

    override fun onResume() {
        super.onResume()
        val cur = Streak.current(this)
        findViewById<TextView>(R.id.stCurrent).text = Lang.num(this, cur)
        findViewById<TextView>(R.id.stCurrentLabel).text = when {
            cur == 0 -> getString(R.string.st_none)
            Streak.isReadToday(this) -> getString(R.string.st_done)
            else -> getString(R.string.st_pending)
        }
        findViewById<TextView>(R.id.stBest).text = Lang.num(this, Streak.best(this))
        findViewById<TextView>(R.id.stTotal).text = Lang.num(this, Streak.total(this))
        findViewById<TextView>(R.id.stKahf).text = Lang.num(this, Streak.kahfFridays(this))

        // Month challenge
        val ym = YearMonth.now()
        val inMonth = Streak.countInMonth(this, ym)
        findViewById<TextView>(R.id.stMonthText).text =
            getString(R.string.month_text, resources.getStringArray(R.array.months)[ym.monthValue - 1],
                Lang.num(this, inMonth), Lang.num(this, ym.lengthOfMonth())) +
            if (inMonth == ym.lengthOfMonth()) getString(R.string.month_full) else ""
        findViewById<ProgressBar>(R.id.stMonthBar).apply { max = ym.lengthOfMonth(); progress = inMonth }
        buildCalendar(ym)

        // Year challenge
        val year = LocalDate.now().year
        val daysInYear = LocalDate.of(year, 12, 31).dayOfYear
        val inYear = Streak.countInYear(this, year)
        findViewById<TextView>(R.id.stYearText).text =
            getString(R.string.year_text, Lang.num(this, year), Lang.num(this, inYear), Lang.num(this, daysInYear)) +
            if (inYear == daysInYear) getString(R.string.year_full) else ""
        findViewById<ProgressBar>(R.id.stYearBar).apply { max = daysInYear; progress = inYear }

        buildBadges()
    }

    private fun buildCalendar(ym: YearMonth) {
        val grid = findViewById<GridLayout>(R.id.stCalendar)
        grid.removeAllViews()
        val d = resources.displayMetrics.density
        val size = (34 * d).toInt()
        val read = Streak.readDays(this)
        val today = LocalDate.now()

        fun cell(text: String, color: Int, bg: Int?) = TextView(this).apply {
            this.text = text
            gravity = Gravity.CENTER
            textSize = 13f
            setTextColor(color)
            if (bg != null) setBackgroundResource(bg)
            layoutParams = GridLayout.LayoutParams(
                GridLayout.spec(GridLayout.UNDEFINED), GridLayout.spec(GridLayout.UNDEFINED, 1f)
            ).apply { width = 0; height = size; setMargins(2, 2, 2, 2) }
        }

        resources.getStringArray(R.array.weekdays).forEach { grid.addView(cell(it, Color.parseColor("#A5D6A7"), null)) }
        // Saturday = column 0
        val first = ym.atDay(1)
        val blank = (first.dayOfWeek.value + 1) % 7
        repeat(blank) { grid.addView(cell("", Color.TRANSPARENT, null)) }
        for (day in 1..ym.lengthOfMonth()) {
            val date = ym.atDay(day)
            val done = date.toEpochDay() in read
            val bg = when { done -> R.drawable.day_on; date == today -> R.drawable.day_today; else -> null }
            val color = if (date.isAfter(today)) Color.parseColor("#4DFFFFFF") else Color.WHITE
            grid.addView(cell(Lang.num(this, day), color, bg))
        }
    }

    private fun buildBadges() {
        val row = findViewById<LinearLayout>(R.id.stBadges)
        row.removeAllViews()
        val best = Streak.best(this)
        val d = resources.displayMetrics.density
        val names = resources.getStringArray(R.array.badges)
        Streak.milestones.forEachIndexed { i, m ->
            val earned = best >= m
            val col = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            }
            col.addView(TextView(this).apply {
                text = Lang.num(this@StatsActivity, m)
                gravity = Gravity.CENTER
                textSize = 14f
                setTypeface(typeface, android.graphics.Typeface.BOLD)
                setTextColor(if (earned) Color.parseColor("#3E2C00") else Color.parseColor("#80FFFFFF"))
                setBackgroundResource(if (earned) R.drawable.badge_on else R.drawable.badge_off)
                layoutParams = LinearLayout.LayoutParams((50 * d).toInt(), (50 * d).toInt())
            })
            col.addView(TextView(this).apply {
                text = names[i]
                textSize = 11f
                setTextColor(if (earned) Color.parseColor("#F2D675") else Color.parseColor("#80FFFFFF"))
                gravity = Gravity.CENTER
                setPadding(0, (4 * d).toInt(), 0, 0)
            })
            row.addView(col)
        }
    }
}
