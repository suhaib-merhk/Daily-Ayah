package com.suhaib.dailyayah

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build

object Notifier {
    private const val CHANNEL = "daily_ayah"
    private const val NOTIFICATION_ID = 1

    fun createChannel(ctx: Context) {
        val channel = NotificationChannel(CHANNEL, "ئایەتی ڕۆژانە", NotificationManager.IMPORTANCE_HIGH).apply {
            description = "ئایەتێکی نوێ هەموو ڕۆژێک"
            lockscreenVisibility = Notification.VISIBILITY_PUBLIC   // full text on lock screen
        }
        ctx.getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }

    fun canNotify(ctx: Context): Boolean =
        Build.VERSION.SDK_INT < 33 ||
            ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    fun show(ctx: Context) {
        createChannel(ctx)
        if (!canNotify(ctx)) return
        val a = AyahRepository.todayAyah(ctx)

        val open = PendingIntent.getActivity(
            ctx, 0,
            Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val n = Notification.Builder(ctx, CHANNEL)
            .setSmallIcon(R.drawable.ic_notification)
            .setColor(0xFF2E7D32.toInt())
            .setContentTitle(a.arabic)
            .setContentText(a.kurdish)
            .setSubText(a.reference)
            .setStyle(
                Notification.BigTextStyle()
                    .setBigContentTitle("ئایەتی ئەمڕۆ · ${a.reference}")
                    .bigText("${a.arabic}\n\n${a.kurdish}")
            )
            .setVisibility(Notification.VISIBILITY_PUBLIC)
            .setCategory(Notification.CATEGORY_REMINDER)
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()

        ctx.getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID, n)
    }
}
