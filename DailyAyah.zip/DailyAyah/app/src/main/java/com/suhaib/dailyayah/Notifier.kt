package com.suhaib.dailyayah

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build

object Notifier {
    private const val CHANNEL = "daily_ayah"
    private const val CHANNEL_REMIND = "reminders"
    private const val NOTIFICATION_ID = 1
    private const val KAHF_ID = 2
    private const val STREAK_ID = 3

    fun createChannel(ctx: Context) {
        val c = Lang.wrap(ctx)
        val daily = NotificationChannel(CHANNEL, c.getString(R.string.ch_daily), NotificationManager.IMPORTANCE_HIGH).apply {
            description = c.getString(R.string.ch_daily_desc)
            lockscreenVisibility = Notification.VISIBILITY_PUBLIC   // full text on lock screen
        }
        val remind = NotificationChannel(CHANNEL_REMIND, c.getString(R.string.ch_remind), NotificationManager.IMPORTANCE_DEFAULT).apply {
            description = c.getString(R.string.ch_remind_desc)
            lockscreenVisibility = Notification.VISIBILITY_PUBLIC
        }
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(daily)
        nm.createNotificationChannel(remind)
    }

    fun canNotify(ctx: Context): Boolean =
        Build.VERSION.SDK_INT < 33 ||
            ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    private fun openIntent(ctx: Context, code: Int, target: Intent) = PendingIntent.getActivity(
        ctx, code, target.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    /** Daily ayah: Arabic + meaning, fully visible on the lock screen. */
    fun show(ctx: Context) {
        createChannel(ctx)
        if (!canNotify(ctx)) return
        val c = Lang.wrap(ctx)
        val a = AyahRepository.todayAyah(ctx)

        val n = Notification.Builder(ctx, CHANNEL)
            .setSmallIcon(R.drawable.ic_notification)
            .setColor(0xFF2E7D32.toInt())
            .setContentTitle(a.arabic)
            .setContentText(a.meaning)
            .setSubText(a.reference)
            .setStyle(
                Notification.BigTextStyle()
                    .setBigContentTitle(c.getString(R.string.notif_today, a.reference))
                    .bigText("${a.arabic}\n\n${a.meaning}")
            )
            .setVisibility(Notification.VISIBILITY_PUBLIC)
            .setCategory(Notification.CATEGORY_REMINDER)
            .setContentIntent(openIntent(ctx, 0, Intent(ctx, MainActivity::class.java)))
            .setAutoCancel(true)
            .build()
        ctx.getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID, n)
    }

    private fun simple(ctx: Context, id: Int, title: String, text: String, target: Intent) {
        createChannel(ctx)
        if (!canNotify(ctx)) return
        val n = Notification.Builder(ctx, CHANNEL_REMIND)
            .setSmallIcon(R.drawable.ic_notification)
            .setColor(0xFF2E7D32.toInt())
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(Notification.BigTextStyle().bigText(text))
            .setVisibility(Notification.VISIBILITY_PUBLIC)
            .setContentIntent(openIntent(ctx, id, target))
            .setAutoCancel(true)
            .build()
        ctx.getSystemService(NotificationManager::class.java).notify(id, n)
    }

    fun showKahf(ctx: Context) {
        val c = Lang.wrap(ctx)
        simple(
            ctx, KAHF_ID, c.getString(R.string.kahf_title), c.getString(R.string.kahf_text),
            Intent(ctx, SurahActivity::class.java).putExtra(SurahActivity.EXTRA_SURAH, 18)
        )
    }

    fun showStreakReminder(ctx: Context) {
        val c = Lang.wrap(ctx)
        val s = Streak.current(ctx)
        val text = if (s > 0) c.getString(R.string.streak_text_has, Lang.num(ctx, s))
                   else c.getString(R.string.streak_text_none)
        simple(ctx, STREAK_ID, c.getString(R.string.streak_title), text, Intent(ctx, MainActivity::class.java))
    }
}
