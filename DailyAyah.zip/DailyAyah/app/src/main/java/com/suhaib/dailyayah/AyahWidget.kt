package com.suhaib.dailyayah

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import java.time.YearMonth

/**
 * Four home-screen widgets:
 *  - AyahWidget      : today's ayah + meaning on a green card
 *  - NatureWidget    : today's ayah on today's nature photo
 *  - StreakWidget    : 🔥 streak, monthly challenge, read today or not
 *  - LineWidget      : just the Arabic ayah, one or two lines
 */
abstract class BaseWidget : AppWidgetProvider() {
    abstract fun build(ctx: Context): RemoteViews

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        try { manager.updateAppWidget(ids, build(context)) } catch (_: Exception) {}
    }

    override fun onAppWidgetOptionsChanged(context: Context, manager: AppWidgetManager, id: Int, newOptions: android.os.Bundle) {
        try { manager.updateAppWidget(id, build(context)) } catch (_: Exception) {}
    }
}

class AyahWidget : BaseWidget() {
    override fun build(ctx: Context) = Widgets.ayah(ctx)

    companion object {
        /** Refreshes every widget type (kept here so older call sites keep working). */
        fun updateAll(ctx: Context) = Widgets.updateAll(ctx)
    }
}

class NatureWidget : BaseWidget() {
    override fun build(ctx: Context) = Widgets.nature(ctx)
}

class StreakWidget : BaseWidget() {
    override fun build(ctx: Context) = Widgets.streak(ctx)
}

class LineWidget : BaseWidget() {
    override fun build(ctx: Context) = Widgets.line(ctx)
}

object Widgets {

    private fun open(ctx: Context, code: Int, target: Class<*>) = PendingIntent.getActivity(
        ctx, code, Intent(ctx, target).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    fun ayah(ctx: Context): RemoteViews {
        val a = AyahRepository.todayAyah(ctx)
        return RemoteViews(ctx.packageName, R.layout.widget_ayah).apply {
            setTextViewText(R.id.w_ref, a.reference)
            setTextViewText(R.id.w_arabic, a.arabic)
            setTextViewText(R.id.w_kurdish, a.meaning)
            setOnClickPendingIntent(R.id.w_root, open(ctx, 11, MainActivity::class.java))
        }
    }

    fun nature(ctx: Context): RemoteViews {
        val a = AyahRepository.todayAyah(ctx)
        return RemoteViews(ctx.packageName, R.layout.widget_nature).apply {
            val bmp = Backgrounds.widgetBitmap(ctx, AyahRepository.today(ctx))
            if (bmp != null) setImageViewBitmap(R.id.wn_bg, bmp) else setImageViewResource(R.id.wn_bg, R.drawable.nature01)
            setTextViewText(R.id.wn_arabic, a.arabic)
            setTextViewText(R.id.wn_meaning, a.meaning)
            setTextViewText(R.id.wn_ref, a.reference)
            setOnClickPendingIntent(R.id.wn_root, open(ctx, 12, MainActivity::class.java))
        }
    }

    fun streak(ctx: Context): RemoteViews {
        val c = Lang.wrap(ctx)
        val s = Streak.current(ctx)
        val ym = YearMonth.now()
        val inMonth = Streak.countInMonth(ctx, ym)
        val read = Streak.isReadToday(ctx)
        return RemoteViews(ctx.packageName, R.layout.widget_streak).apply {
            setTextViewText(R.id.ws_count, Lang.num(ctx, s))
            setTextViewText(R.id.ws_label, c.getString(R.string.w_days))
            setProgressBar(R.id.ws_month_bar, ym.lengthOfMonth(), inMonth, false)
            setTextViewText(R.id.ws_month, c.getString(R.string.w_month, Lang.num(ctx, inMonth), Lang.num(ctx, ym.lengthOfMonth())))
            setTextViewText(R.id.ws_status, c.getString(if (read) R.string.w_read else R.string.w_not_read))
            setTextColor(R.id.ws_status, if (read) 0xFFA5D6A7.toInt() else 0xFFFFB74D.toInt())
            // Not read yet → open today's ayah; already read → open the streak page
            setOnClickPendingIntent(R.id.ws_root,
                if (read) open(ctx, 13, StatsActivity::class.java) else open(ctx, 14, MainActivity::class.java))
        }
    }

    fun line(ctx: Context): RemoteViews {
        val a = AyahRepository.todayAyah(ctx)
        return RemoteViews(ctx.packageName, R.layout.widget_line).apply {
            setTextViewText(R.id.wl_arabic, a.arabic)
            setTextViewText(R.id.wl_ref, a.reference)
            setOnClickPendingIntent(R.id.wl_root, open(ctx, 15, MainActivity::class.java))
        }
    }

    private val providers = listOf(
        AyahWidget::class.java to ::ayah,
        NatureWidget::class.java to ::nature,
        StreakWidget::class.java to ::streak,
        LineWidget::class.java to ::line
    )

    fun updateAll(ctx: Context) {
        val manager = AppWidgetManager.getInstance(ctx)
        for ((cls, make) in providers) {
            try {
                val ids = manager.getAppWidgetIds(ComponentName(ctx, cls))
                if (ids.isNotEmpty()) manager.updateAppWidget(ids, make(ctx))
            } catch (_: Exception) {}
        }
    }
}
