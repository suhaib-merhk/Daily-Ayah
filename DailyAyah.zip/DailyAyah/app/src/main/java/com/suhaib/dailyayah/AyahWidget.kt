package com.suhaib.dailyayah

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews

/** Home-screen widget showing today's ayah. */
class AyahWidget : AppWidgetProvider() {

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        manager.updateAppWidget(ids, views(context))
    }

    companion object {
        private fun views(ctx: Context): RemoteViews {
            val a = AyahRepository.todayAyah(ctx)
            val open = PendingIntent.getActivity(
                ctx, 1, Intent(ctx, MainActivity::class.java),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            return RemoteViews(ctx.packageName, R.layout.widget_ayah).apply {
                setTextViewText(R.id.w_ref, a.reference)
                setTextViewText(R.id.w_arabic, a.arabic)
                setTextViewText(R.id.w_kurdish, a.kurdish)
                setOnClickPendingIntent(R.id.w_root, open)
            }
        }

        fun updateAll(ctx: Context) {
            val manager = AppWidgetManager.getInstance(ctx)
            val ids = manager.getAppWidgetIds(ComponentName(ctx, AyahWidget::class.java))
            if (ids.isNotEmpty()) manager.updateAppWidget(ids, views(ctx))
        }
    }
}
