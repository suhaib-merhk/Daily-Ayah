package com.suhaib.dailyayah

import android.content.Context

/** All user settings in one place. */
object Settings {
    private fun p(ctx: Context) = AyahRepository.prefs(ctx)

    fun notifyEnabled(ctx: Context) = p(ctx).getBoolean("notify", true)
    fun setNotifyEnabled(ctx: Context, v: Boolean) = p(ctx).edit().putBoolean("notify", v).apply()

    fun hour(ctx: Context) = p(ctx).getInt("hour", 8)
    fun minute(ctx: Context) = p(ctx).getInt("minute", 0)
    fun setTime(ctx: Context, h: Int, m: Int) = p(ctx).edit().putInt("hour", h).putInt("minute", m).apply()

    /** 0..8  →  text scale 0.8 .. 1.6 */
    fun sizeStep(ctx: Context) = p(ctx).getInt("size_step", 2)
    fun setSizeStep(ctx: Context, v: Int) = p(ctx).edit().putInt("size_step", v).apply()
    fun textScale(ctx: Context) = 0.8f + sizeStep(ctx) * 0.1f

    /** "daily", "fixed" or "custom" */
    fun bgMode(ctx: Context) = p(ctx).getString("bg_mode", "daily") ?: "daily"
    fun setBgMode(ctx: Context, v: String) = p(ctx).edit().putString("bg_mode", v).apply()
    fun fixedBg(ctx: Context) = p(ctx).getInt("fixed_bg", 0)
    fun setFixedBg(ctx: Context, v: Int) = p(ctx).edit().putInt("fixed_bg", v).apply()

    fun reciter(ctx: Context) = p(ctx).getInt("reciter", 0)
    fun setReciter(ctx: Context, v: Int) = p(ctx).edit().putInt("reciter", v).apply()
}

object Reciters {
    val names = arrayOf(
        "مشاری ڕاشد العفاسی",
        "عبدالباسط عبدالصمد",
        "محمود خلیل الحصری",
        "عبدالرحمن السدیس",
        "ماهر المعیقلی"
    )
    private val folders = arrayOf(
        "Alafasy_128kbps",
        "Abdul_Basit_Murattal_192kbps",
        "Husary_128kbps",
        "Abdurrahmaan_As-Sudais_192kbps",
        "MaherAlMuaiqly128kbps"
    )

    fun url(ctx: Context, a: Ayah): String {
        val i = Settings.reciter(ctx).coerceIn(0, folders.size - 1)
        return "https://everyayah.com/data/${folders[i]}/%03d%03d.mp3".format(a.surah, a.number)
    }
}
