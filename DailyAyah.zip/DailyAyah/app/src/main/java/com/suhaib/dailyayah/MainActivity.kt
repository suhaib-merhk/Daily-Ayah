package com.suhaib.dailyayah

import android.Manifest
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.File

class MainActivity : Activity() {

    companion object { const val EXTRA_DAY = "day" }

    private var offset = 0                // 0 = today, 1 = yesterday ...
    private var shownDay = 0
    private var current: Ayah? = null
    private var player: MediaPlayer? = null

    private lateinit var arabic: TextView
    private lateinit var kurdish: TextView
    private lateinit var reference: TextView
    private lateinit var counter: TextView
    private lateinit var dateText: TextView
    private lateinit var btnPrev: TextView
    private lateinit var btnNext: TextView
    private lateinit var btnPlay: ImageButton
    private lateinit var btnFav: ImageButton
    private lateinit var progress: ProgressBar
    private lateinit var bg: ImageView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        arabic = findViewById(R.id.arabic)
        kurdish = findViewById(R.id.kurdish)
        reference = findViewById(R.id.reference)
        counter = findViewById(R.id.counter)
        dateText = findViewById(R.id.dateText)
        btnPrev = findViewById(R.id.btnPrev)
        btnNext = findViewById(R.id.btnNext)
        btnPlay = findViewById(R.id.btnPlay)
        btnFav = findViewById(R.id.btnFav)
        progress = findViewById(R.id.progress)
        bg = findViewById(R.id.bg)

        Notifier.createChannel(this)
        askNotificationPermission()
        Scheduler.scheduleAll(this)
        AyahWidget.updateAll(this)

        findViewById<ImageButton>(R.id.btnHistory).setOnClickListener { openList(ListActivity.MODE_HISTORY) }
        findViewById<ImageButton>(R.id.btnFavorites).setOnClickListener { openList(ListActivity.MODE_FAVORITES) }
        findViewById<ImageButton>(R.id.btnSettings).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
        findViewById<ImageButton>(R.id.btnShare).setOnClickListener { share() }
        findViewById<ImageButton>(R.id.btnCopy).setOnClickListener { copy() }
        btnPlay.setOnClickListener { togglePlay() }
        btnFav.setOnClickListener { toggleFavorite() }
        btnPrev.setOnClickListener { if (shownDay > 0) { offset++; render() } }
        btnNext.setOnClickListener { if (offset > 0) { offset--; render() } }
        dateText.setOnClickListener { if (offset != 0) { offset = 0; render() } }

        readDayExtra(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        readDayExtra(intent)
    }

    private fun readDayExtra(intent: Intent?) {
        val day = intent?.getIntExtra(EXTRA_DAY, -1) ?: -1
        offset = if (day >= 0) (AyahRepository.today(this) - day).coerceAtLeast(0) else 0
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    override fun onStop() {
        super.onStop()
        stopPlay()
    }

    private fun render() {
        stopPlay()
        val today = AyahRepository.today(this)
        if (offset > today) offset = today
        shownDay = today - offset
        val a = AyahRepository.ayahForDay(this, shownDay)
        current = a

        arabic.text = a.arabic
        kurdish.text = a.kurdish
        reference.text = a.reference

        // Long ayat get smaller text; user size setting multiplies it
        val len = a.arabic.length + a.kurdish.length
        val scale = Settings.textScale(this)
        arabic.textSize = scale * when { len < 300 -> 27f; len < 700 -> 23f; len < 1200 -> 19f; else -> 16f }
        kurdish.textSize = scale * when { len < 300 -> 17f; len < 700 -> 15f; len < 1200 -> 13f; else -> 12f }
        findViewById<ScrollView>(R.id.scroll).scrollTo(0, 0)

        Backgrounds.apply(this, bg, shownDay)

        val pos = shownDay % AyahRepository.TOTAL + 1
        counter.text = "ئایەتی ${arabicDigits(pos)} لە ${arabicDigits(AyahRepository.TOTAL)}"
        progress.progress = pos
        dateText.text = if (offset == 0) "ئەمڕۆ" else AyahRepository.dateOf(this, shownDay).toString()
        btnNext.alpha = if (offset == 0) 0.3f else 1f
        btnPrev.alpha = if (shownDay == 0) 0.3f else 1f
        updateFavIcon()
    }

    private fun updateFavIcon() {
        btnFav.setImageResource(
            if (AyahRepository.isFavorite(this, shownDay)) R.drawable.ic_heart else R.drawable.ic_heart_outline
        )
    }

    private fun toggleFavorite() {
        val added = AyahRepository.toggleFavorite(this, shownDay)
        updateFavIcon()
        toast(if (added) "زیادکرا بۆ دڵخوازەکان" else "لە دڵخوازەکان لابرا")
    }

    private fun togglePlay() {
        if (player != null) { stopPlay(); return }
        val a = current ?: return
        val mp = MediaPlayer()
        player = mp
        btnPlay.setImageResource(R.drawable.ic_stop)
        toast("چاوەڕێ بکە…")
        mp.setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build()
        )
        mp.setOnPreparedListener { if (player === it) it.start() }
        mp.setOnCompletionListener { if (player === it) stopPlay() }
        mp.setOnErrorListener { p, _, _ ->
            if (player === p) { stopPlay(); toast("ئینتەرنێت پێویستە بۆ گوێگرتن") }
            true
        }
        try {
            mp.setDataSource(Reciters.url(this, a))
            mp.prepareAsync()
        } catch (e: Exception) {
            stopPlay()
            toast("ئینتەرنێت پێویستە بۆ گوێگرتن")
        }
    }

    private fun stopPlay() {
        player?.let { try { it.release() } catch (_: Exception) {} }
        player = null
        if (::btnPlay.isInitialized) btnPlay.setImageResource(R.drawable.ic_play)
    }

    private fun copy() {
        val a = current ?: return
        getSystemService(ClipboardManager::class.java)
            .setPrimaryClip(ClipData.newPlainText("ayah", a.shareText))
        toast("کۆپی کرا")
    }

    private fun share() {
        val a = current ?: return
        val card = findViewById<View>(R.id.card)
        val bmp = Bitmap.createBitmap(card.width, card.height, Bitmap.Config.ARGB_8888)
        card.draw(Canvas(bmp))
        val dir = File(cacheDir, "share").apply { mkdirs() }
        File(dir, "ayah.png").outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
        val uri = Uri.parse("content://$packageName.share/ayah.png")

        val send = Intent(Intent.ACTION_SEND).apply {
            type = "image/png"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_TEXT, a.shareText)
            clipData = ClipData.newRawUri("ayah", uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(send, "هاوبەشکردن"))
    }

    private fun openList(mode: String) {
        startActivity(Intent(this, ListActivity::class.java).putExtra(ListActivity.EXTRA_MODE, mode))
    }

    private fun askNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
}
