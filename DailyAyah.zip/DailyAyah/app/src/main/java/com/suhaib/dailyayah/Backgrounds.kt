package com.suhaib.dailyayah

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import android.widget.ImageView
import java.io.File

object Backgrounds {
    val nature = intArrayOf(
        R.drawable.nature01, R.drawable.nature02, R.drawable.nature03, R.drawable.nature04, R.drawable.nature05,
        R.drawable.nature06, R.drawable.nature07, R.drawable.nature08, R.drawable.nature09, R.drawable.nature10,
        R.drawable.nature11, R.drawable.nature12, R.drawable.nature13, R.drawable.nature14, R.drawable.nature15,
        R.drawable.nature16, R.drawable.nature17, R.drawable.nature18, R.drawable.nature19, R.drawable.nature20,
        R.drawable.nature21, R.drawable.nature22, R.drawable.nature23, R.drawable.nature24, R.drawable.nature25,
        R.drawable.nature26, R.drawable.nature27, R.drawable.nature28, R.drawable.nature29, R.drawable.nature30
    )

    private fun customFile(ctx: Context) = File(ctx.filesDir, "custom_bg.jpg")

    /** A background is either a real photo (assets/photos) or a painted picture (drawable). */
    sealed class Bg {
        data class Photo(val path: String) : Bg()
        data class Painted(val res: Int) : Bg()
    }

    private var photoCache: List<String>? = null

    /** Real Unsplash photos bundled at build time (may be empty if the download was skipped). */
    fun photos(ctx: Context): List<String> = photoCache ?: try {
        (ctx.assets.list("photos") ?: emptyArray()).filter { it.endsWith(".jpg") }.sorted().map { "photos/$it" }
    } catch (e: Exception) { emptyList() }.also { photoCache = it }

    /** Photographer credits, "Name" per line. */
    fun credits(ctx: Context): List<String> = try {
        ctx.assets.open("photos/credits.txt").bufferedReader().readLines()
            .mapNotNull { it.split('|').getOrNull(1)?.trim() }.filter { it.isNotEmpty() }.distinct()
    } catch (e: Exception) { emptyList() }

    /** Every picture, real photos first, then painted ones. Used for the "fixed" choice. */
    fun all(ctx: Context): List<Bg> = photos(ctx).map { Bg.Photo(it) } + nature.map { Bg.Painted(it) }

    /** Which picture to show on a given day, following the user's setting. */
    fun forDay(ctx: Context, day: Int): Bg {
        val photos = photos(ctx)
        return when (Settings.bgMode(ctx)) {
            "fixed" -> all(ctx).let { it[Settings.fixedBg(ctx).coerceIn(0, it.size - 1)] }
            "daily" -> Bg.Painted(nature[day % nature.size])
            else -> if (photos.isNotEmpty()) Bg.Photo(photos[day % photos.size])   // "photos" (default)
                    else Bg.Painted(nature[day % nature.size])
        }
    }

    fun apply(ctx: Context, view: ImageView, day: Int) {
        if (Settings.bgMode(ctx) == "custom") {
            val bmp = decodeFile(customFile(ctx), 1600)
            if (bmp != null) { view.setImageBitmap(bmp); return }
        }
        when (val bg = forDay(ctx, day)) {
            is Bg.Painted -> view.setImageResource(bg.res)
            is Bg.Photo -> {
                val bmp = decodeAsset(ctx, bg.path, 1600, false)
                if (bmp != null) view.setImageBitmap(bmp) else view.setImageResource(nature[day % nature.size])
            }
        }
    }

    /** Small, memory-light bitmap for home-screen widgets. */
    fun widgetBitmap(ctx: Context, day: Int, maxDim: Int = 640): Bitmap? {
        if (Settings.bgMode(ctx) == "custom") decodeFile(customFile(ctx), maxDim, true)?.let { return it }
        return when (val bg = forDay(ctx, day)) {
            is Bg.Photo -> decodeAsset(ctx, bg.path, maxDim, true)
            is Bg.Painted -> BitmapFactory.decodeResource(ctx.resources, bg.res,
                BitmapFactory.Options().apply { inSampleSize = 2; inPreferredConfig = Bitmap.Config.RGB_565 })
        }
    }

    fun thumbnail(ctx: Context, bg: Bg): Bitmap? = when (bg) {
        is Bg.Painted -> BitmapFactory.decodeResource(ctx.resources, bg.res, BitmapFactory.Options().apply { inSampleSize = 4 })
        is Bg.Photo -> decodeAsset(ctx, bg.path, 200, true)
    }

    private fun decodeAsset(ctx: Context, path: String, maxDim: Int, small: Boolean): Bitmap? = try {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        ctx.assets.open(path).use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (bounds.outWidth / (sample * 2) >= maxDim || bounds.outHeight / (sample * 2) >= maxDim * 2) sample *= 2
        ctx.assets.open(path).use {
            BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply {
                inSampleSize = sample
                if (small) inPreferredConfig = Bitmap.Config.RGB_565
            })
        }
    } catch (e: Exception) { null }

    /** Copies a gallery photo into the app, shrunk and rotated upright. */
    fun saveCustom(ctx: Context, uri: Uri): Boolean = try {
        val tmp = File(ctx.cacheDir, "pick.tmp")
        ctx.contentResolver.openInputStream(uri)!!.use { input -> tmp.outputStream().use { input.copyTo(it) } }
        var bmp = decodeFile(tmp, 1600) ?: throw IllegalStateException("bad image")
        val rotation = when (ExifInterface(tmp.path).getAttributeInt(
            ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
            ExifInterface.ORIENTATION_ROTATE_90 -> 90f
            ExifInterface.ORIENTATION_ROTATE_180 -> 180f
            ExifInterface.ORIENTATION_ROTATE_270 -> 270f
            else -> 0f
        }
        if (rotation != 0f) {
            bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, Matrix().apply { postRotate(rotation) }, true)
        }
        customFile(ctx).outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 88, it) }
        tmp.delete()
        true
    } catch (e: Exception) {
        false
    }

    private fun decodeFile(file: File, maxDim: Int, small: Boolean = false): Bitmap? {
        if (!file.exists()) return null
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(file.path, bounds)
        var sample = 1
        while (bounds.outWidth / (sample * 2) >= maxDim || bounds.outHeight / (sample * 2) >= maxDim * 2) sample *= 2
        return BitmapFactory.decodeFile(file.path, BitmapFactory.Options().apply {
            inSampleSize = sample
            if (small) inPreferredConfig = Bitmap.Config.RGB_565
        })
    }
}
