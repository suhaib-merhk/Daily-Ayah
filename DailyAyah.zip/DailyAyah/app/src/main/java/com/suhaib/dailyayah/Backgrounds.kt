package com.suhaib.dailyayah

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import android.widget.ImageView
import java.io.File

object Backgrounds {
    val nature = intArrayOf(
        R.drawable.nature01, R.drawable.nature02, R.drawable.nature03, R.drawable.nature04,
        R.drawable.nature05, R.drawable.nature06, R.drawable.nature07, R.drawable.nature08,
        R.drawable.nature09, R.drawable.nature10
    )

    private fun customFile(ctx: Context) = File(ctx.filesDir, "custom_bg.jpg")

    fun apply(ctx: Context, view: ImageView, day: Int) {
        when (Settings.bgMode(ctx)) {
            "custom" -> {
                val bmp = decodeFile(customFile(ctx), 1600)
                if (bmp != null) { view.setImageBitmap(bmp); return }
            }
            "fixed" -> {
                view.setImageResource(nature[Settings.fixedBg(ctx).coerceIn(0, nature.size - 1)]); return
            }
        }
        view.setImageResource(nature[day % nature.size])
    }

    fun thumbnail(ctx: Context, index: Int): Bitmap? =
        BitmapFactory.decodeResource(ctx.resources, nature[index], BitmapFactory.Options().apply { inSampleSize = 4 })

    /** Copies a gallery photo into the app, shrunk and rotated upright. */
    fun saveCustom(ctx: Context, uri: Uri): Boolean = try {
        val tmp = File(ctx.cacheDir, "pick.tmp")
        ctx.contentResolver.openInputStream(uri)!!.use { input -> tmp.outputStream().use { input.copyTo(it) } }
        var bmp = decodeFile(tmp, 1600) ?: throw IllegalStateException("bad image")
        val rotation = when (ExifInterface(tmp.path).getAttributeInt(
            ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
            ExifInterface.ORIENTATION_ROTATE_90 -> 90f
            ExifInterface.ORIENTATION_ROTATE_180 -> 180f
            ExifInterface.ORIENTATION_ROTATE_270 -> 270f
            else -> 0f
        }
        if (rotation != 0f) {
            bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, Matrix().apply { postRotate(rotation) }, true)
        }
        customFile(ctx).outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 88, it) }
        tmp.delete()
        true
    } catch (e: Exception) {
        false
    }

    private fun decodeFile(file: File, maxDim: Int): Bitmap? {
        if (!file.exists()) return null
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(file.path, bounds)
        var sample = 1
        while (bounds.outWidth / sample > maxDim * 2 || bounds.outHeight / sample > maxDim * 2) sample *= 2
        return BitmapFactory.decodeFile(file.path, BitmapFactory.Options().apply { inSampleSize = sample })
    }
}
