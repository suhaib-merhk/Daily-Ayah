package com.suhaib.dailyayah

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageButton
import android.widget.ListView
import android.widget.TextView

/** History of past days, or the favorites list. */
class ListActivity : Activity() {

    companion object {
        const val EXTRA_MODE = "mode"
        const val MODE_HISTORY = "history"
        const val MODE_FAVORITES = "favorites"
    }

    private var days: List<Int> = emptyList()
    private lateinit var adapter: DayAdapter
    private lateinit var mode: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_list)
        mode = intent.getStringExtra(EXTRA_MODE) ?: MODE_HISTORY

        findViewById<TextView>(R.id.title).text =
            if (mode == MODE_FAVORITES) "ئایەتە دڵخوازەکان" else "ئایەتەکانی ڕۆژانی پێشوو"
        findViewById<ImageButton>(R.id.btnBack).setOnClickListener { finish() }

        adapter = DayAdapter()
        val list = findViewById<ListView>(R.id.list)
        list.adapter = adapter
        list.setOnItemClickListener { _, _, position, _ ->
            startActivity(
                Intent(this, MainActivity::class.java)
                    .putExtra(MainActivity.EXTRA_DAY, days[position])
                    .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            )
            finish()
        }
    }

    override fun onResume() {
        super.onResume()
        days = if (mode == MODE_FAVORITES) AyahRepository.favorites(this)
        else (AyahRepository.today(this) downTo 0).toList()
        adapter.notifyDataSetChanged()

        val empty = findViewById<TextView>(R.id.empty)
        empty.text = "هێشتا هیچ ئایەتێکت زیاد نەکردووە.\nلە شاشەی سەرەکی دوگمەی ❤ دابگرە."
        empty.visibility = if (days.isEmpty()) View.VISIBLE else View.GONE
    }

    private inner class DayAdapter : BaseAdapter() {
        override fun getCount() = days.size
        override fun getItem(position: Int): Any = days[position]
        override fun getItemId(position: Int) = days[position].toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val v = convertView ?: layoutInflater.inflate(R.layout.item_ayah, parent, false)
            val day = days[position]
            val a = AyahRepository.ayahForDay(this@ListActivity, day)
            v.findViewById<TextView>(R.id.i_ref).text = a.reference
            v.findViewById<TextView>(R.id.i_date).text =
                if (day == AyahRepository.today(this@ListActivity)) "ئەمڕۆ"
                else AyahRepository.dateOf(this@ListActivity, day).toString()
            v.findViewById<TextView>(R.id.i_arabic).text = a.arabic
            v.findViewById<TextView>(R.id.i_kurdish).text = a.kurdish
            return v
        }
    }
}
