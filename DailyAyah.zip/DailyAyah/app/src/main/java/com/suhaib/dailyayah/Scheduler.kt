package com.suhaib.dailyayah

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import java.time.ZonedDateTime

/** Books the daily notification and a small midnight job that refreshes the widget. */
object Scheduler {
    const val ACTION_DAILY = "com.suhaib.dailyayah.DAILY"
    const val ACTION_MIDNIGHT = "com.suhaib.dailyayah.MIDNIGHT"

    private fun pending(ctx: Context, action: String, code: Int) = PendingIntent.getBroadcast(
        ctx, code, Intent(ctx, AlarmReceiver::class.java).setAction(action),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    fun scheduleAll(ctx: Context) {
        scheduleDaily(ctx)
        scheduleMidnight(ctx)
    }

    fun scheduleDaily(ctx: Context) {
        val am = ctx.getSystemService(AlarmManager::class.java)
        val pi = pending(ctx, ACTION_DAILY, 100)
        if (!Settings.notifyEnabled(ctx)) { am.cancel(pi); return }

        val now = ZonedDateTime.now()
        var next = now.withHour(Settings.hour(ctx)).withMinute(Settings.minute(ctx)).withSecond(0).withNano(0)
        if (!next.isAfter(now)) next = next.plusDays(1)
        val at = next.toInstant().toEpochMilli()

        if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        } else {
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        }
    }

    fun scheduleMidnight(ctx: Context) {
        val am = ctx.getSystemService(AlarmManager::class.java)
        val at = ZonedDateTime.now().toLocalDate().plusDays(1).atTime(0, 1)
            .atZone(ZonedDateTime.now().zone).toInstant().toEpochMilli()
        am.setAndAllowWhileIdle(AlarmManager.RTC, at, pending(ctx, ACTION_MIDNIGHT, 101))
    }
}
