package com.suhaib.dailyayah

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import java.time.DayOfWeek
import java.time.ZonedDateTime

/**
 * Alarms:
 *  - daily ayah notification (user's time)
 *  - midnight widget refresh
 *  - Friday Surah al-Kahf reminder
 *  - 21:00 streak reminder (only notifies if today isn't read yet)
 */
object Scheduler {
    const val ACTION_DAILY = "com.suhaib.dailyayah.DAILY"
    const val ACTION_MIDNIGHT = "com.suhaib.dailyayah.MIDNIGHT"
    const val ACTION_KAHF = "com.suhaib.dailyayah.KAHF"
    const val ACTION_STREAK = "com.suhaib.dailyayah.STREAK"

    private fun pending(ctx: Context, action: String, code: Int) = PendingIntent.getBroadcast(
        ctx, code, Intent(ctx, AlarmReceiver::class.java).setAction(action),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    fun scheduleAll(ctx: Context) {
        scheduleDaily(ctx)
        scheduleMidnight(ctx)
        scheduleKahf(ctx)
        scheduleStreak(ctx)
    }

    private fun set(ctx: Context, at: Long, pi: PendingIntent, exact: Boolean) {
        val am = ctx.getSystemService(AlarmManager::class.java)
        if (exact && (Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms())) {
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        } else {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        }
    }

    private fun nextAt(hour: Int, minute: Int, day: DayOfWeek? = null): Long {
        val now = ZonedDateTime.now()
        var next = now.withHour(hour).withMinute(minute).withSecond(0).withNano(0)
        if (day != null) while (next.dayOfWeek != day) next = next.plusDays(1)
        if (!next.isAfter(now)) next = next.plusDays(if (day != null) 7 else 1)
        return next.toInstant().toEpochMilli()
    }

    fun scheduleDaily(ctx: Context) {
        val pi = pending(ctx, ACTION_DAILY, 100)
        if (!Settings.notifyEnabled(ctx)) { ctx.getSystemService(AlarmManager::class.java).cancel(pi); return }
        set(ctx, nextAt(Settings.hour(ctx), Settings.minute(ctx)), pi, true)
    }

    fun scheduleMidnight(ctx: Context) {
        set(ctx, nextAt(0, 1), pending(ctx, ACTION_MIDNIGHT, 101), false)
    }

    fun scheduleKahf(ctx: Context) {
        val pi = pending(ctx, ACTION_KAHF, 102)
        if (!Settings.kahfEnabled(ctx)) { ctx.getSystemService(AlarmManager::class.java).cancel(pi); return }
        set(ctx, nextAt(Settings.kahfHour(ctx), Settings.kahfMinute(ctx), DayOfWeek.FRIDAY), pi, true)
    }

    fun scheduleStreak(ctx: Context) {
        val pi = pending(ctx, ACTION_STREAK, 103)
        if (!Settings.streakReminder(ctx)) { ctx.getSystemService(AlarmManager::class.java).cancel(pi); return }
        set(ctx, nextAt(21, 0), pi, false)
    }
}
