package com.suhaib.dailyayah

import android.content.Context
import android.content.SharedPreferences
import java.time.LocalDate
import kotlin.random.Random

data class Ayah(
    val index: Int,        // 0..6235 in Quran order
    val surah: Int,
    val number: Int,
    val surahName: String,
    val arabic: String,
    val kurdish: String
) {
    /** e.g. "سُوْرَةُ النَّحْلِ ﴿٢٠﴾" */
    val reference: String get() = "$surahName ﴿${arabicDigits(number)}﴾"
    val shareText: String get() = "$arabic\n\n$kurdish\n\n$reference"
}

fun arabicDigits(n: Int): String = n.toString().map { '٠' + (it - '0') }.joinToString("")

/**
 * One ayah per day from all 6236, random order, no repeats.
 * A seed saved on first launch fixes the order; every cycle of 6236 days
 * gets a new shuffle, so nothing repeats until all have been shown (~17 years).
 */
object AyahRepository {
    const val TOTAL = 6236
    private const val PREFS = "daily_ayah"

    private var lines: List<String>? = null
    private var surahNames: List<String>? = null
    private val orders = HashMap<Int, IntArray>()

    fun prefs(ctx: Context): SharedPreferences =
        ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    private fun ensureInit(ctx: Context) {
        val p = prefs(ctx)
        if (!p.contains("start_day")) {
            p.edit()
                .putLong("start_day", LocalDate.now().toEpochDay())
                .putLong("seed", Random.nextLong())
                .apply()
        }
    }

    private fun startDay(ctx: Context): Long {
        ensureInit(ctx)
        return prefs(ctx).getLong("start_day", LocalDate.now().toEpochDay())
    }

    /** 0 = the first day the app was opened. */
    fun today(ctx: Context): Int =
        (LocalDate.now().toEpochDay() - startDay(ctx)).toInt().coerceAtLeast(0)

    fun dateOf(ctx: Context, day: Int): LocalDate = LocalDate.ofEpochDay(startDay(ctx) + day)

    @Synchronized
    fun indexForDay(ctx: Context, day: Int): Int {
        ensureInit(ctx)
        val cycle = day / TOTAL
        val order = orders.getOrPut(cycle) {
            val seed = prefs(ctx).getLong("seed", 0L)
            val list = (0 until TOTAL).toMutableList()
            list.shuffle(Random(seed + cycle))
            list.toIntArray()
        }
        return order[day % TOTAL]
    }

    fun ayahForDay(ctx: Context, day: Int): Ayah = ayahAt(ctx, indexForDay(ctx, day))

    fun todayAyah(ctx: Context): Ayah = ayahForDay(ctx, today(ctx))

    @Synchronized
    fun ayahAt(ctx: Context, index: Int): Ayah {
        val all = lines ?: ctx.assets.open("quran.tsv").bufferedReader(Charsets.UTF_8)
            .readLines().filter { it.isNotBlank() }.also { lines = it }
        val names = surahNames ?: ctx.assets.open("surahs.tsv").bufferedReader(Charsets.UTF_8)
            .readLines().filter { it.isNotBlank() }.map { it.split('\t')[1] }.also { surahNames = it }
        val p = all[index].split('\t')
        val surah = p[0].toInt()
        return Ayah(index, surah, p[1].toInt(), names[surah - 1], p[2], p[3])
    }

    // ---------- Favorites (stored as day numbers, newest first) ----------

    fun favorites(ctx: Context): List<Int> =
        (prefs(ctx).getString("favorites", "") ?: "")
            .split(',').filter { it.isNotBlank() }.map { it.toInt() }

    fun isFavorite(ctx: Context, day: Int) = day in favorites(ctx)

    /** Returns true if it is now a favorite. */
    fun toggleFavorite(ctx: Context, day: Int): Boolean {
        val list = favorites(ctx).toMutableList()
        val added = if (day in list) { list.remove(day); false } else { list.add(0, day); true }
        prefs(ctx).edit().putString("favorites", list.joinToString(",")).apply()
        return added
    }
}
