plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.suhaib.dailyayah"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.suhaib.dailyayah"
        minSdk = 26
        targetSdk = 34
        versionCode = 6
        versionName = "3.3"
    }

    // One fixed key, so every new build installs over the old one and keeps your data
    signingConfigs {
        create("shared") {
            storeFile = file("dailyayah.keystore")
            storePassword = "dailyayah"
            keyAlias = "dailyayah"
            keyPassword = "dailyayah"
        }
    }

    buildTypes {
        getByName("debug") { signingConfig = signingConfigs.getByName("shared") }
        getByName("release") {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("shared")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    // no external libraries needed
}
